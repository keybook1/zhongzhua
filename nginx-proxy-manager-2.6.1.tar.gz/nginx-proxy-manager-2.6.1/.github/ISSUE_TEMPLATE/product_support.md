---
name: Product Support
about: Need help configuring the software?
title: ''
labels: product-support
assignees: ''

---

**Checklist**
- Please read the [setup instructions](https://nginxproxymanager.com/setup/)
- Please read the [FAQ](https://nginxproxymanager.com/faq/)

**What is troubling you?**

_Clear and concise description of what you're trying to do and what isn't working for you_
