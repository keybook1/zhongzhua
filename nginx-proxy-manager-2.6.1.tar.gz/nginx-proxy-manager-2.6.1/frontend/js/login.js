const App = require('./login/main');

$(document).ready(() => {
    App.start();
});
